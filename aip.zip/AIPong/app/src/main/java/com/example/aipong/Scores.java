package com.example.aipong;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class Scores extends AppCompatActivity {

    private String readFromFile(Context context) {
        String ret = "";

        try {
            InputStream inputStream = context.openFileInput("configa4.txt");

            if ( inputStream != null ) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String receiveString = "";
                StringBuilder stringBuilder = new StringBuilder();

                while ( (receiveString = bufferedReader.readLine()) != null ) {
                    stringBuilder.append("\n").append(receiveString);
                }

                inputStream.close();
                ret = stringBuilder.toString();
            }
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return ret;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scores);
        setTitle("Scores");

        String scoresDat = readFromFile(Scores.this);
        StringTokenizer st2 = new StringTokenizer(scoresDat, "\n");
        ArrayList<Line> l =new ArrayList<>();
        FileWriter writer = null;

        String cont = "";

        final ListView lv1 = (ListView) findViewById(R.id.et);

        while (st2.hasMoreElements()) {
            String value = st2.nextToken();
            StringTokenizer st3 = new StringTokenizer(value, " ");

            String value2 = st3.nextToken();
            String value3 = st3.nextToken();

            cont += value2 + " " + value3;

            Line line = new Line();
            line.name = value2;
            line.score = value3;

            l.add(line);
        }

        lv1.setAdapter(new MyCustomBaseAdapter(this, l));

        TextView play = (TextView) findViewById(R.id.play);
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mainIntent = new Intent(Scores.this, MainActivity.class);
                startActivity(mainIntent);
                finish();
            }
        });
    }
}