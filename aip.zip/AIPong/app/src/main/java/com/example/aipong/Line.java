package com.example.aipong;

public class Line {
    String name;
    String score;
}
