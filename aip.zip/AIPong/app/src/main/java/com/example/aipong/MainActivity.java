package com.example.aipong;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.bumptech.glide.Glide;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class MainActivity extends AppCompatActivity {

    Thread t;

    LinearLayout Container;

    ArrayList<View> textList = new ArrayList<>();

    String m_Text = "";

    int count = 0;

    int multiple_time = 1;

    int score = 0, scr = 0;

    ImageView ball;

    Button paddle1, paddle2;

    TextView left, right;

    int x_move = 12;
    int y_move = 12;

    int x = 180;
    int y = 130;

    Context context;

    ImageView leftbutton, rightbutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle("");

        context = this;

        leftbutton = (ImageView) findViewById(R.id.leftarrow1);

        rightbutton = (ImageView) findViewById(R.id.rightarrow1);

        TextView bt = (TextView) findViewById(R.id.scores);
        bt.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                Intent mainIntent = new Intent(MainActivity.this, Scores.class);
                startActivity(mainIntent);
                finish();

                return true;
            }
        });

        leftbutton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                paddle1 = (Button) findViewById(R.id.paddle1);
                paddle1.setX(paddle1.getX() - 12);

                if (paddle1.getX() <= ball.getX() + 140 && paddle1.getX() >= ball.getX() - 40 - 170 &&
                        paddle1.getY() <= ball.getY() + 10 + 40 && paddle1.getY() >= ball.getY() - 10 + 40 - 40) {

                    x_move -= 6;
                    ball.setX(ball.getX() + x_move);
                }

                return true;
            }
        });

        rightbutton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                paddle1 = (Button) findViewById(R.id.paddle1);
                paddle1.setX(paddle1.getX() + 12);

                if (paddle1.getX() <= ball.getX() + 140 && paddle1.getX() >= ball.getX() - 40 - 170 &&
                        paddle1.getY() <= ball.getY() + 10 + 40 && paddle1.getY() >= ball.getY() - 10 + 40 - 40) {

                    x_move += 6;
                    ball.setX(ball.getX() + x_move);
                }

                return true;
            }
        });

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setIcon(R.mipmap.aiponglogo);

        Glide.with(context)
                .load(R.drawable.leftarrow1)
                .into(leftbutton);

        Glide.with(context)
                .load(R.drawable.rightarrow1)
                .into(rightbutton);

        String dir = getFilesDir().getAbsolutePath();

        final File resolveMe = new File("/data/user/0/com.example.aipong/files/configa4.txt");
        if(!resolveMe.exists()) {
            try {
                resolveMe.createNewFile();
            } catch(Exception e) {e.printStackTrace();}
        }

        paddle2 = (Button) findViewById(R.id.paddle2);
        paddle1 = (Button) findViewById(R.id.paddle1);

        paddle1.setX(300);
        paddle1.setY(740);

        Thread t1 = new Thread() {
            public void run() {
                while(true) {
                    try {
                        Thread.sleep(10);

                        if(paddle2.getX() > ball.getX()) {
                            if(paddle2.getX() >= 12)
                                paddle2.setX(paddle2.getX() - 2*multiple_time);
                        } else if(paddle2.getX() < ball.getX()) {
                            if(paddle2.getX() + 6*multiple_time <= 1052)
                                paddle2.setX(paddle2.getX() + 2*multiple_time);
                        }

                        paddle1.invalidate();
                        paddle2.invalidate();
                        ball.invalidate();

                    } catch(Exception e) {}
                }
            }
        };
        t1.start();

        TextView save = (TextView) findViewById(R.id.save);
        save.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                String scoresDat = readFromFile(context);
                StringTokenizer st = new StringTokenizer(scoresDat, "\n");
                ArrayList<Line> lines = new ArrayList();
                while(st.hasMoreElements()) {
                    String value = st.nextToken();
                    StringTokenizer st2 = new StringTokenizer(value, " ");

                    String value2 = st2.nextToken();
                    String value3 = st2.nextToken();

                    Line line = new Line();
                    line.name = value2;
                    line.score = value3;

                    lines.add(line);

                }

                int max = 0;
                int maxid = 0;
                for(int i=0; i<lines.size(); i++) {
                    String v1 = lines.get(i).score;
                    v1 = v1.replaceAll("[^\\d.]", "");
                    int w = Integer.parseInt(v1);
                    if(w > max) {
                        max = w;
                        maxid = i;
                    }
                }

                if(score > max) {

                    Line newline = new Line();

                    newline.name = m_Text;
                    newline.score = score + "";

                    if(!m_Text.equals("")) {

                        String scoresDat2 = readFromFile(context);
                        StringTokenizer st2 = new StringTokenizer(scoresDat2, "\n");
                        ArrayList<Line> l =new ArrayList<>();

                        while (st2.hasMoreElements()) {
                            String value = st2.nextToken();
                            StringTokenizer st3 = new StringTokenizer(value, " ");

                            String value2 = st3.nextToken();
                            String value3 = st3.nextToken();

                            Line line = new Line();
                            line.name = value2;
                            line.score = value3;

                            l.add(line);

                        }

                        FileWriter writer = null;

                        try {
                            writer = new FileWriter(resolveMe);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        try {
                            writer.append("\n" + newline.name + " " + newline.score + "\n");

                            try {
                                for (int i = l.size() - 1; i >= 0; i--) {
                                    writer.append(l.get(i).name + " " + l.get(i).score);
                                    if (i > 0)
                                        writer.append("\n");
                                }
                            } catch(Exception e) {}
                            writer.flush();
                            writer.close();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }


                    }

                }

                Intent mainIntent = new Intent(MainActivity.this, Scores.class);
                startActivity(mainIntent);
                finish();

                return true;
            }
        });

        TextView play = (TextView) findViewById(R.id.play);
        play.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                paddle1.setX(300);
                paddle1.setY(740);

                x_move = 12*multiple_time;
                y_move = 12*multiple_time;

                x = 180;
                y = 130;

                ball.setX(x);
                ball.setY(y);

                score = 0;
                scr = 0;

                return false;
            }
        });

        ball = (ImageView) findViewById(R.id.ball);
        t = new Thread() {
            public void run() {
                while(true) {
                    try {
                        Thread.sleep(40);

                        ball.setX(x);
                        ball.setY(y);

                        if(!(y > 800)) {

                            if (y <= 0) {
                                y_move = -y_move;
                                score += 1;
                                TextView tv = (TextView) findViewById(R.id.score);
                                tv.setText("You : " + score + " Phone : " + scr);
                                tv.setTextColor(Color.DKGRAY);

                                y_move = 12*multiple_time;

                                y += y_move;

                            } else {

                                if (x >= 1070 - 26)
                                    x_move = -12 * multiple_time;

                                if (x <= 12)
                                    x_move = 12 * multiple_time;

                                x += x_move;

                                if (paddle1.getX() <= ball.getX() + 140 && paddle1.getX() >= ball.getX() - 40 - 170 &&
                                        paddle1.getY() <= ball.getY() + 10 + 40 && paddle1.getY() >= ball.getY() - 10 + 40 - 40) {
                                    if (y_move > 0) {
                                        y_move = -y_move;
                                    }
                                }

                                if (paddle2.getX() <= ball.getX() + 140 && paddle2.getX() >= ball.getX() - 40 - 170 &&
                                        paddle2.getY() <= ball.getY() + 4 + 0 && paddle2.getY() >= ball.getY() - 10) {
                                    y_move = -y_move;
                                }

                                y += y_move;
                            }

                        } else {

                            Container = (LinearLayout) findViewById(R.id.Container);

                            for (int i = 0; i < Container.getChildCount(); i++) {
                                textList.add(Container.getChildAt(i));
                            }

                            fadeView(textList.get(0));

                            if (y >= 800) {
                                y_move = -y_move;
                                scr += 1;
                                TextView tv = (TextView) findViewById(R.id.score);
                                tv.setText("You : " + score + " Phone : " + scr);
                                tv.setTextColor(Color.DKGRAY);
                            }

                            paddle1.setX(300);
                            paddle1.setY(740);

                            x_move = 12*multiple_time;
                            y_move = 12*multiple_time;

                            x = 180;
                            y = 130;

                            ball.setX(x);
                            ball.setY(y);

                        }
                    } catch(Exception e) {}
                }
            }
        };

        Container = (LinearLayout) findViewById(R.id.Container);

        for (int i = 0; i < Container.getChildCount(); i++) {
            textList.add(Container.getChildAt(i));
        }

        fadeView(textList.get(0));

        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Your NickName");

        // Set up the input
        final EditText input = new EditText(MainActivity.this);
        builder.setView(input);

        // Set up the buttons
        builder.setPositiveButton("Play", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                m_Text = input.getText().toString();
                t.start();
            }
        });

        AlertDialog alert11 = builder.create();
        alert11.show();
    }

    private void fadeView(final View view) {
        final Animation anim = AnimationUtils.loadAnimation(this, R.anim.fadein);
        count++;

        anim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) { }

            @Override
            public void onAnimationEnd(Animation animation) {
                if (count == textList.size()) return;
                fadeView(textList.get(count));
            }

            @Override
            public void onAnimationRepeat(Animation animation) { }
        });

        view.startAnimation(anim);
    }

    private String readFromFile(Context context) {

        String ret = "";

        try {

            InputStream inputStream = context.openFileInput("configa4.txt");

            if ( inputStream != null ) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String receiveString = "";
                StringBuilder stringBuilder = new StringBuilder();

                while ( (receiveString = bufferedReader.readLine()) != null ) {
                    stringBuilder.append("\n").append(receiveString);
                }

                inputStream.close();
                ret = stringBuilder.toString();
            }
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return ret;
    }
}